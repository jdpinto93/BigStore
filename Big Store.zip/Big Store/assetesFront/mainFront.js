jQuery(document).ready(function( $ ){
	$(".preloader").fadeOut("slow");
});