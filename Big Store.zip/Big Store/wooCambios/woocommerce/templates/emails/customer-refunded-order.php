<!DOCTYPE html>
<html lang="en-US">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Bigcom</title>
</head>
<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0">
<?php if( !isset( $order ) && isset( $gift_card->order_id ) ){
				$order = wc_get_order( $gift_card->order_id );
			} ?><?php if( isset( $order ) && is_a( $order, 'WC_Order_Refund' ) ){
				$order = wc_get_order( $order->get_parent_id() );
			} ?><table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="thwec_template_wrapper"><tr><td align="center" class="thwec-template-wrapper-column" valign="top" style="background-color: #f7f7f7; padding: 70px 0;"><div id="thwec_template_container"><table id="tp_temp_builder" width="600" cellspacing="0" cellpadding="0" class="main-builder thwec-template-block" style="max-width: 600px; width: 600px; margin: auto; box-sizing: border-box;"><tr><td class="thwec-builder-column" style="vertical-align: top; border-style: solid; border-color: #f6f7fa; background-color: #f6f6f6; background-image: none; background-position: center; background-size: 100%; background-repeat: no-repeat; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;">
<table class="thwec-row thwec-block-one-column builder-block" id="tp_1006" cellpadding="0" cellspacing="0" style="border-spacing: 0px; width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border-style: none; border-color: transparent; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;"><tr><td class="column-padding thwec-col thwec-columns" id="tp_1007" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; vertical-align: top; width: 100%; border-style: none; border-color: transparent; background-color: transparent; background-image: none; background-position: center; background-size: 100%; background-repeat: no-repeat; text-align: center; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px;"><table class="thwec-block thwec-block-image builder-block" id="tp_1019" cellspacing="0" cellpadding="0" align="center" style="table-layout: fixed; width: 100%; height: auto; max-width: 600px; box-sizing: border-box; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-color: transparent;">
		<tr>
			<td class="thwec-block-child thwec-image-column" style="padding: 0; vertical-align: top; box-sizing: border-box; text-align: center;"><p style="padding: 5px 5px; margin: 0; display: inline-block; max-width: 100%; vertical-align: top; width: 100%; height: auto; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
			<img src="https://bigcom.com.mx/cdn/uploads/2022/05/Banner-enmaquetado-E-mail-2.png" alt="Image" width="598" height="269.094" style="width: 100%; height: auto; display: block;">
		</p></td>
</tr>
</table></td></tr></table>
<table class="thwec-row thwec-block-one-column builder-block" id="tp_1009" cellpadding="0" cellspacing="0" style="border-spacing: 0px; width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border-style: none; border-color: transparent; background-image: url('https://bigcom.com.mx/cdn/uploads/2022/05/E-mail-marketing-pedido-1-1.png'); background-color: #fefefe; background-position: center; background-size: 100%; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;"><tr><td class="column-padding thwec-col thwec-columns" id="tp_1010" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; vertical-align: top; width: 100%; border-style: none; border-color: #dddddd; background-color: transparent; background-image: none; background-position: center; background-size: 100%; background-repeat: no-repeat; text-align: left; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 15px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px;">
<table class="thwec-block thwec-block-header builder-block thwec-block-set" id="tp_1020" cellspacing="0" cellpadding="0" align="center" style="table-layout: fixed; overflow: hidden; text-align: center; box-sizing: border-box; position: relative; margin: 0 auto; max-width: 100%; width: 100%; background-color: #ff0000; background-image: none; background-repeat: no-repeat; background-position: center; background-size: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
<tr>
			<td class="header-text" style="vertical-align: top; box-sizing: border-box; padding: 30px 0px 30px 0px; font-size: 0; padding-top: 15px; padding-right: 0px; padding-bottom: 15px; padding-left: 0px;">
				<h1 style="margin: 0 auto; width: 100%; max-width: 100%; mso-line-height-rule: exactly; vertical-align: middle; border: 1px solid transparent; box-sizing: border-box; font-size: 40px; color: #ffffff; font-weight: 650; text-align: center; line-height: 100%; font-family: Arial, Helvetica, sans-serif;">Tu Pedido #<?php if(isset($order)) : ?><?php echo $order->get_id();?><?php endif; ?> esta siendo reembolsado!</h1>
			</td>
		</tr>
	</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1011" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; font-size: 18px; line-height: 22px; font-weight: 600; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; text-align: left;">
		<tr style="color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; text-align: left; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 20px; padding-right: 0px; padding-bottom: 0px; padding-left: 10px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">¡<?php if(isset($order)) : ?><?php echo $order->get_billing_first_name(); ?><?php elseif ( isset( $user_login ) ) : ?><?php $user = get_user_by('login', $user_login ); echo $user->first_name; ?><?php endif; ?>, el monto de tu compra ha sido reembolsado!<br style="color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
<div class="wec-txt-wrap" style="color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"><br style="color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"></div>
<div class="wec-txt-wrap" style="color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">Tu pedido se ha reembolsado, en un periodo de 3 a 4 días hábiles el monto de tu compra se verá reflejada en tu cuenta.<br style="color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
<div class="wec-txt-wrap" style="color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"><br style="color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"></div>
<div class="wec-txt-wrap" style="color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">Agracedemos tu preferencia por Bigcom<br style="color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1064" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; text-align: center; font-size: 17px; line-height: 22px; font-weight: 700; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #000000; font-size: 17px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 17px; font-weight: 700; line-height: 22px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 17px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">¡Es nuestro desafío ser tu mejor opción!<br style="color: #000000; font-size: 17px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
<?php if(isset($order)){ ?>
		<table class="thwec-block thwec-block-order builder-block" id="tp_1021" cellpadding="0" cellspacing="0" align="center" style="table-layout: fixed; margin: 0 auto; position: relative; background-position: center; text-align: center; width: 100%; background-color: transparent; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-image: none; background-size: 100%; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
			<tr class="before_order_table"></tr>
			<tr>
				<td class="order-padding" align="center" style="vertical-align: top; box-sizing: border-box; word-break: unset; padding: 20px 48px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px;">
					<?php $text_align = is_rtl() ? "right" : "left"; ?>
  					<h2 class="thwec-order-heading" style="color: #000000; font-size: 28px; text-align: center; font-weight: bold; line-height: 100%; font-family: Arial, Helvetica, sans-serif;"><?php
		if ( $sent_to_admin ) {
			$before = '<a class="link" style="color:inherit;font-weight:inherit;font-size:inherit;font-family:inherit;line-height:inherit;" href="' . esc_url( $order->get_edit_order_url() ) . '">';
			$after  = '</a>';
		} else {
			$before = "";
			$after  = "";}
		echo wp_kses_post( $before . sprintf( __( 'Pedido#%s', 'woocommerce-email-customizer-pro' ) . $after . ' (<time datetime="%s">%s</time>)', $order->get_order_number(), $order->get_date_created()->format( 'c' ), wc_format_datetime( $order->get_date_created() ) ) );
		?></h2>
					<table class="thwec-order-table thwec-td" cellpadding="0" cellspacing="0" neue helvetica roboto arial sans-serif style="border-collapse: collapse; border: 1px solid #e5e5e5; padding: 12px; table-layout: auto; width: 100%; background-color: transparent; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-size: 15px; color: #000000; text-align: left; font-family: Arial, Helvetica, sans-serif; border-color: #ff0000; line-height: 150%; padding-top: 10px; padding-right: 0px; padding-bottom: 10px; padding-left: 5px;">
						<thead>
							<tr>
								<th class="thwec-td order-head thwec-td-order-product" scope="col" style="word-break: keep-all; border: 1px solid #e5e5e5; padding: 12px; font-size: 15px; color: #000000; text-align: left; font-family: Arial, Helvetica, sans-serif; border-color: #ff0000; line-height: 150%; padding-top: 10px; padding-right: 0px; padding-bottom: 10px; padding-left: 5px;"><?php echo __( apply_filters("thwec_rename_order_total_labels", "Product"), 'woocommerce' ); ?></th>
								<th class="thwec-td order-head thwec-td-order-quantity" scope="col" style="word-break: keep-all; border: 1px solid #e5e5e5; padding: 12px; font-size: 15px; color: #000000; text-align: left; font-family: Arial, Helvetica, sans-serif; border-color: #ff0000; line-height: 150%; padding-top: 10px; padding-right: 0px; padding-bottom: 10px; padding-left: 5px;"><?php echo __( apply_filters("thwec_rename_order_total_labels", "Quantity"), 'woocommerce' ); ?></th>
								<th class="thwec-td order-head thwec-td-order-price" scope="col" style="word-break: keep-all; border: 1px solid #e5e5e5; padding: 12px; font-size: 15px; color: #000000; text-align: left; font-family: Arial, Helvetica, sans-serif; border-color: #ff0000; line-height: 150%; padding-top: 10px; padding-right: 0px; padding-bottom: 10px; padding-left: 5px;"><?php echo __( apply_filters("thwec_rename_order_total_labels", "Price"), 'woocommerce' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php 
		$items = $order->get_items();
		foreach ( $items as $item_id => $item ) :
	$product = $item->get_product();
	if ( apply_filters( "woocommerce_order_item_visible", true, $item ) ) {
		?>
							<tr class="<?php echo esc_attr( apply_filters( 'woocommerce_order_item_class', 'order_item', $item, $order ) ); ?>">
								<td class="order-item thwec-td" style="box-sizing: border-box; word-break: keep-all; border: 1px solid #e5e5e5; padding: 12px; font-size: 15px; color: #000000; text-align: left; font-family: Arial, Helvetica, sans-serif; border-color: #ff0000; line-height: 150%; padding-top: 10px; padding-right: 0px; padding-bottom: 10px; padding-left: 5px; vertical-align: middle;"><?php $show_image = false;$show_sku = apply_filters( "thwec_show_order_table_sku", $sent_to_admin, $item_id, $item, $order, $plain_text );

				// Show title/image etc
				if ( $show_image ) {
					echo apply_filters( 'woocommerce_order_item_thumbnail', '<div style="margin-bottom: 5px"><img src="' . ( $product->get_image_id() ? current( wp_get_attachment_image_src( $product->get_image_id(), 'thumbnail' ) ) : wc_placeholder_img_src() ) . '" alt="' . esc_attr__( 'Product image', 'woocommerce' ) . '" height="' . esc_attr( $image_size[1] ) .'" width="' . esc_attr( $image_size[0] ) . '" style="vertical-align:middle; margin-' . ( is_rtl() ? 'left' : 'right' ) . ': 10px;" /></div>', $item );
				}

				// Product name
				echo apply_filters( 'woocommerce_order_item_name', $item->get_name(), $item, false );

				// SKU
				if ( $show_sku && is_object( $product ) && $product->get_sku() ) {
					echo ' (#' . $product->get_sku() . ')';
				}

				// allow other plugins to add additional product information here
				do_action( 'woocommerce_order_item_meta_start', $item_id, $item, $order, $plain_text );

				wc_display_item_meta( $item );

				// allow other plugins to add additional product information here
				do_action( 'woocommerce_order_item_meta_end', $item_id, $item, $order, $plain_text );

			?></td>
								<td class="order-item-qty thwec-td" style="box-sizing: border-box; word-break: keep-all; border: 1px solid #e5e5e5; padding: 12px; font-size: 15px; color: #000000; text-align: left; font-family: Arial, Helvetica, sans-serif; border-color: #ff0000; line-height: 150%; padding-top: 10px; padding-right: 0px; padding-bottom: 10px; padding-left: 5px; vertical-align: middle;"><?php echo apply_filters( 'woocommerce_email_order_item_quantity', $item->get_quantity(), $item ); ?></td>
								<td class="order-item-price thwec-td" style="box-sizing: border-box; word-break: keep-all; border: 1px solid #e5e5e5; padding: 12px; font-size: 15px; color: #000000; text-align: left; font-family: Arial, Helvetica, sans-serif; border-color: #ff0000; line-height: 150%; padding-top: 10px; padding-right: 0px; padding-bottom: 10px; padding-left: 5px; vertical-align: middle;"><?php echo $order->get_formatted_line_subtotal( $item ); ?></td>
							</tr>								
							<?php
		}
		$show_purchase_note=true;
		if ( $show_purchase_note && is_object( $product ) && ( $purchase_note = $product->get_purchase_note() ) ) : ?>
			<tr>
				<td colspan="3" style="text-align:<?php echo $text_align; ?>;vertical-align:middle; border: 1px solid #eee; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;"><?php echo wpautop( do_shortcode( wp_kses_post( $purchase_note ) ) );?></td>
			</tr>
		<?php endif; ?>
		<?php endforeach; ?>
						</tbody>
						<tfoot class="order-footer">
							<?php
		if(isset($order)){
			$totals = $order->get_order_item_totals();
			if ( $totals ) {
				$i = 0;
				foreach ( $totals as $total ) {
					$i++;
					?>
							<tr class="order-footer-row">
								<th class="order-total-label thwec-td" scope="row" colspan="2" style="word-break: keep-all; border: 1px solid #e5e5e5; padding: 12px; font-size: 15px; color: #000000; text-align: left; font-family: Arial, Helvetica, sans-serif; border-color: #ff0000; line-height: 150%; padding-top: 10px; padding-right: 0px; padding-bottom: 10px; padding-left: 5px;"><?php echo wp_kses_post( apply_filters("thwec_rename_order_total_labels", $total['label']) ); ?></th>
								<td class="order-total-value thwec-td" style="vertical-align: top; box-sizing: border-box; word-break: keep-all; border: 1px solid #e5e5e5; padding: 12px; font-size: 15px; color: #000000; text-align: left; font-family: Arial, Helvetica, sans-serif; border-color: #ff0000; line-height: 150%; padding-top: 10px; padding-right: 0px; padding-bottom: 10px; padding-left: 5px;"><?php echo wp_kses_post( $total['value'] ); ?></td>
							</tr>							
							<?php
				}
			}
			if ( isset($order) && $order->get_customer_note() ) {
				?>
				<tr>
					<th class="td" scope="row" colspan="2" style="color:#000000;text-align:left;font-size:15px;line-height:150%;font-weight:;padding-top:10px;padding-right:0px;padding-bottom:10px;padding-left:5px;border-color:#ff0000;font-family:Arial, Helvetica, sans-serif;"><?php esc_html_e( 'Note:', 'woocommerce' ); ?></th>
					<td class="td" style="color:#000000;text-align:left;font-size:15px;line-height:150%;font-weight:;padding-top:10px;padding-right:0px;padding-bottom:10px;padding-left:5px;border-color:#ff0000;font-family:Arial, Helvetica, sans-serif;"><?php echo wp_kses_post( wptexturize( $order->get_customer_note() ) ); ?></td>
				</tr>
				<?php
			}
		}
			?>
						</tfoot>
					</table>
					<blocksettings block="{true}" dragprovided="{provided}" oneditblock="{this.props.onEditBlock}" blockid="{this.props.dragId}" blockname='{"order_details"}' ondeleteblock="{this.props.onDeleteBlock}"></blocksettings>
  				</td>
  			</tr>
  		</table>
		<?php } ?>
</td></tr></table>
<table class="thwec-row thwec-block-one-column builder-block" id="tp_1047" cellpadding="0" cellspacing="0" style="width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border-spacing: 0px; padding-top: 0px; padding-right: 10px; padding-bottom: 12px; padding-left: 10px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: url('https://bigcom.com.mx/cdn/uploads/2022/05/E-mail-marketing-pedido-1-2.png'); background-color: #ffffff; background-position: center; background-size: 100%; background-repeat: no-repeat;"><tr><td class="column-padding thwec-col thwec-columns" id="tp_1048" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 100%; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; text-align: center; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; vertical-align: top;">
<table class="thwec-block thwec-block-text builder-block" id="tp_1022" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; text-align: center; font-size: 17px; line-height: 22px; font-weight: 650; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 10px; padding-right: 5px; padding-bottom: 0px; padding-left: 5px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">Podras cambiar el medio e pago y revisar el estatus y el detalle de tu pedido en la sección de Mis Pedidos,<br style="color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
<div class="wec-txt-wrap" style="color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"><br style="color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"></div>
			</td>
		</tr>
	</table>
<table class="thwec-block thwec-button-wrapper-table builder-block" id="tp_1038" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; width: 280px; height: 20px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; padding-top: 10px; padding-right: 0px; padding-bottom: 10px; padding-left: 0px;">
		<tr>
			<td class="thwec-block-child thwec-button-wrapper" style="vertical-align: top; box-sizing: border-box; border-radius: 2px; padding: 10px 0px; text-decoration: none; font-size: 18px; font-family: Tahoma, Geneva, sans-serif; color: #ffffff; background-color: #ff0000; background-image: none; background-repeat: no-repeat; background-size: 100%; background-position: center; border-top-width: 2px; border-bottom-width: 2px; border-left-width: 2px; border-right-width: 2px; border-style: solid; border-color: #ffffff; padding-top: 10px; padding-right: 0px; padding-bottom: 10px; padding-left: 0px; text-align: center;">
      			<a href="https://bigcom.com.mx/login/orders/" title="VER ESTATUS DEL PEDIDO" class="thwec-button-link" style="text-decoration: none; line-height: 150%; font-size: 18px; font-family: Tahoma, Geneva, sans-serif; color: #ffffff; text-align: center;">VER ESTATUS DEL PEDIDO</a>
  			</td>
		</tr>
	</table>
</td></tr></table>
<table class="thwec-row thwec-block-two-column builder-block" id="tp_1030" cellpadding="0" cellspacing="0" style="border-spacing: 0px; width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; padding-top: 12px; padding-right: 10px; padding-bottom: 12px; padding-left: 10px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: transparent; background-image: url('https://bigcom.com.mx/cdn/uploads/2022/05/E-mail-marketing-pedido-1-3.png'); background-color: #ffffff; background-position: center; background-size: 100%; background-repeat: no-repeat;"><tr>
<td class="column-padding thwec-col thwec-columns" id="tp_1031" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 50%; padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; text-align: center; vertical-align: top;">
<?php if(isset($order)){?>
        <table class="thwec-block thwec-block-billing builder-block" id="tp_1033" cellspacing="0" cellpadding="0" align="center" style="width: 100%; table-layout: fixed; margin: 0; padding: 0; border: 0px none transparent; border-collapse: collapse; box-sizing: border-box;">
			<tr>
				<td class="thwec-block-child thwec-address-alignment" align="center" style="vertical-align: top; margin: 0; padding: 0; border: 0px none transparent; border-collapse: collapse; box-sizing: border-box;">  	
					<table class="thwec-address-wrapper-table" cellpadding="0" cellspacing="0" style="width: 100%; height: 115px; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px;">
						<tr>
							<td class="billing-padding" style="vertical-align: top; box-sizing: border-box; padding: 5px 0px 2px 0px; padding-top: 5px; padding-right: 0px; padding-bottom: 2px; padding-left: 0px;">
								<h2 class="thwec-billing-header" style="display: block; margin: 0px; font-size: 23px; color: #ff0000; text-align: center; font-weight: bold; line-height: 100%; font-family: Arial, Helvetica, sans-serif;">Detalles de Facturacion</h2>
		      					<p class="address thwec-billing-body" style="margin: 13px 0px; padding: 0px 0px 0px 0px; font-size: 15px; color: #000000; text-align: left; font-family: Arial, Helvetica, sans-serif; font-weight: 600; line-height: 150%; border: 0px;">
		      						<?php echo wp_kses_post( $order->get_formatted_billing_address( esc_html__( "N/A", "woocommerce" ) ) ); ?>
				<?php if ( $order->get_billing_phone() ) : ?>
					<br><?php echo wc_make_phone_clickable( $order->get_billing_phone() ); ?>
				<?php endif; ?><?php if ( $order->get_billing_email() ) : ?>
					<br><a class="thwec-link" href="mailto:<?php echo esc_html( $order->get_billing_email() ); ?>"><?php echo esc_html( $order->get_billing_email() ); ?></a>
				<?php endif; ?>
		      					</p>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<?php } ?>
</td>
<td class="column-padding thwec-col thwec-columns" id="tp_1032" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 50%; padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; text-align: center; vertical-align: top;">
<?php if(isset($order)){?>
	<?php if ( ! wc_ship_to_billing_address_only() && $order->needs_shipping_address() && ( $shipping = $order->get_formatted_shipping_address() ) ) : ?>
	<table class="thwec-block thwec-block-shipping builder-block" id="tp_1034" cellspacing="0" cellpadding="0" align="center" style="width: 100%; table-layout: fixed; margin: 0; padding: 0; border: 0px none transparent; border-collapse: collapse; box-sizing: border-box;">
		<tr>
			<td class="thwec-block-child thwec-address-alignment" align="center" style="vertical-align: top; margin: 0; padding: 0; border: 0px none transparent; border-collapse: collapse; box-sizing: border-box;">
				<table class="thwec-address-wrapper-table" cellpadding="0" cellspacing="0" style="width: 100%; height: 115px; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px;">
					<tr>
						<td class="shipping-padding" style="vertical-align: top; box-sizing: border-box; padding: 5px 0px 2px 0px; padding-top: 5px; padding-right: 0px; padding-bottom: 2px; padding-left: 0px;">
 							<h2 class="thwec-shipping-header" style="display: block; margin: 0px; font-size: 23px; color: #ff0000; text-align: center; font-weight: bold; line-height: 100%; font-family: Arial, Helvetica, sans-serif;">Detalles de Envio</h2>
							<p class="address thwec-shipping-body" style="margin: 13px 0px; padding: 0px 0px 0px 0px; font-size: 15px; color: #000000; text-align: left; font-family: Arial, Helvetica, sans-serif; font-weight: 600; line-height: 150%; border: 0px;">
								<?php echo $order->get_formatted_shipping_address(); ?>
							</p>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	<?php endif; ?>
	<?php } ?>
</td>
</tr></table>
<table class="thwec-row thwec-block-four-column builder-block" id="tp_1051" cellpadding="0" cellspacing="0" style="border-spacing: 0px; width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; padding-top: 12px; padding-right: 10px; padding-bottom: 12px; padding-left: 10px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: url('https://bigcom.com.mx/cdn/uploads/2022/05/E-mail-marketing-pedido-1-3.png'); background-color: #ffffff; background-position: center; background-size: 100%; background-repeat: no-repeat;"><tr>
<td class="column-padding thwec-col thwec-columns" id="tp_1052" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 25%; padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; text-align: center; vertical-align: top;">
<table class="thwec-block thwec-block-image builder-block" id="tp_1056" cellspacing="0" cellpadding="0" align="center" style="table-layout: fixed; width: 100%; height: auto; max-width: 600px; box-sizing: border-box; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-color: transparent;">
		<tr>
			<td class="thwec-block-child thwec-image-column" style="padding: 0; vertical-align: top; box-sizing: border-box; text-align: center;"><p style="padding: 5px 5px; margin: 0; display: inline-block; max-width: 100%; vertical-align: top; width: 100%; height: 85px; padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
			<img src="https://bigcom.com.mx/cdn/uploads/2022/05/Iconos-PUV-5-150px-1.png" alt="Image" width="124.5" height="85" style="width: 100%; height: auto; display: block;">
		</p></td>
</tr>
</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1060" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; text-align: center; font-size: 9px; line-height: 15px; font-weight: 800; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">Compras 100% Seguras<br style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
</td>
<td class="column-padding thwec-col thwec-columns" id="tp_1053" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 25%; padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; text-align: center; vertical-align: top;">
<table class="thwec-block thwec-block-image builder-block" id="tp_1057" cellspacing="0" cellpadding="0" align="center" style="table-layout: fixed; width: 100%; height: auto; max-width: 600px; box-sizing: border-box; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-color: transparent;">
		<tr>
			<td class="thwec-block-child thwec-image-column" style="padding: 0; vertical-align: top; box-sizing: border-box; text-align: center;"><p style="padding: 5px 5px; margin: 0; display: inline-block; max-width: 100%; vertical-align: top; width: 100%; height: 85px; padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
			<img src="https://bigcom.com.mx/cdn/uploads/2022/05/Iconos-PUV-2-150px-2.png" alt="Image" width="124.5" height="85" style="width: 100%; height: auto; display: block;">
		</p></td>
</tr>
</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1061" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; text-align: center; font-size: 9px; line-height: 15px; font-weight: 800; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">Entregas el mismo Día<br style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
</td>
<td class="column-padding thwec-col thwec-columns" id="tp_1054" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 25%; padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; text-align: center; vertical-align: top;">
<table class="thwec-block thwec-block-image builder-block" id="tp_1058" cellspacing="0" cellpadding="0" align="center" style="table-layout: fixed; width: 100%; height: auto; max-width: 600px; box-sizing: border-box; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-color: transparent;">
		<tr>
			<td class="thwec-block-child thwec-image-column" style="padding: 0; vertical-align: top; box-sizing: border-box; text-align: center;"><p style="padding: 5px 5px; margin: 0; display: inline-block; max-width: 100%; vertical-align: top; width: 100%; height: 85px; padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
			<img src="https://bigcom.com.mx/cdn/uploads/2022/05/Iconos-PUV-1-150px-1.png" alt="Image" width="124.5" height="85" style="width: 100%; height: auto; display: block;">
		</p></td>
</tr>
</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1062" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; text-align: center; font-size: 9px; line-height: 15px; font-weight: 800; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">Meses sin Tarjetas de Credito<br style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
</td>
<td class="column-padding thwec-col thwec-columns" id="tp_1055" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 25%; padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; text-align: center; vertical-align: top;">
<table class="thwec-block thwec-block-image builder-block" id="tp_1059" cellspacing="0" cellpadding="0" align="center" style="table-layout: fixed; width: 100%; height: auto; max-width: 600px; box-sizing: border-box; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-color: transparent;">
		<tr>
			<td class="thwec-block-child thwec-image-column" style="padding: 0; vertical-align: top; box-sizing: border-box; text-align: center;"><p style="padding: 5px 5px; margin: 0; display: inline-block; max-width: 100%; vertical-align: top; width: 100%; height: 85px; padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
			<img src="https://bigcom.com.mx/cdn/uploads/2022/05/Iconos-PUV-3-150px-1.png" alt="Image" width="124.5" height="85" style="width: 100%; height: auto; display: block;">
		</p></td>
</tr>
</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1063" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; text-align: center; font-size: 9px; line-height: 15px; font-weight: 800; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">Atencion en linea<br style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
</td>
</tr></table>
<table class="thwec-row thwec-block-one-column builder-block" id="tp_1035" cellpadding="0" cellspacing="0" style="width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border-spacing: 0px; padding-top: 12px; padding-right: 10px; padding-bottom: 12px; padding-left: 10px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: #444444; background-position: center; background-size: 100%; background-repeat: no-repeat;"><tr><td class="column-padding thwec-col thwec-columns" id="tp_1036" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 100%; padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px; text-align: center; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; vertical-align: top;">
<table class="thwec-block thwec-block-image builder-block" id="tp_1050" cellspacing="0" cellpadding="0" align="center" style="table-layout: fixed; width: 100%; height: auto; max-width: 600px; box-sizing: border-box; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-color: transparent;">
		<tr>
			<td class="thwec-block-child thwec-image-column" style="padding: 0; vertical-align: top; box-sizing: border-box; text-align: center;"><p style="padding: 5px 5px; margin: 0; display: inline-block; max-width: 100%; vertical-align: top; width: 25%; height: 100px; padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
			<img src="https://bigcom.com.mx/cdn/uploads/2022/05/Rojo.png" alt="Image" width="139.5" height="100" style="width: 100%; height: auto; display: block;">
		</p></td>
</tr>
</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1037" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #ffffff; text-align: center; font-size: 14px; line-height: 22px; font-weight: 700; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #ffffff; font-size: 14px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #ffffff; font-size: 14px; font-weight: 700; line-height: 22px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">¿Tienes alguna pregunta? Escribenos a contacto@bigcom.com.mx o puedes llamarnos al (222) 1696636<br style="color: #ffffff; font-size: 14px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1041" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #ffffff; text-align: left; font-size: 14px; line-height: 22px; font-weight: 500; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; text-align: left; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">-- El precio, especificaciones de producto, disponibilidad y términos de las promociones pueden cambiar sin previo aviso.<br style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"><br style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"></div>
<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">-- Los precios y artículos en este correo están sujetos a disponibilidad.<br style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"><br style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"></div>
			</td>
		</tr>
	</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1040" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #ffffff; text-align: center; font-size: 14px; line-height: 22px; font-weight: 600; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">Bigcom © 2021. All Rights Reserved.<br style="color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"><br style="color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"></div>
<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">Av. Pinos, Sta Cruz Buenavista, 72170 Puebla, Pue.<br style="color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
<table class="thwec-block thwec-block-social builder-block" id="tp_1039" cellspacing="0" cellpadding="0" style="table-layout: fixed; width: 100%; box-sizing: border-box; margin: 0 auto; text-align: center; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
		<tr>
			<td class="thwec-block-child thwec-social-outer-td" align="center" style="padding: 0; vertical-align: top; box-sizing: border-box; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px;">
				<table class="thwec-social-inner-tb" cellspacing="0" cellpadding="0">
					<tr>
<td class="thwec-social-td thwec-td-fb" style="vertical-align: top; box-sizing: border-box; padding: 15px 3px 15px 3px; font-size: 0; line-height: 1px; padding-top: 15px; padding-right: 3px; padding-bottom: 15px; padding-left: 3px; text-align: center;">
			<p class="thwec-social-icon" style="margin: 0px; text-decoration: none; box-shadow: none; width: 40px; height: 40px;">
				<a href="https://www.facebook.com/BigcomOficial" class="facebook">
					<img src="https://bigcom.com.mx/cdn/uploads/2022/05/RS-1.png" alt="Facebook Icon" width="40" height="40" style="width: 100%; height: 100%; display: block;">
				</a>
			</p>
		</td>
<td class="thwec-social-td thwec-td-mail" style="vertical-align: top; box-sizing: border-box; padding: 15px 3px 15px 3px; font-size: 0; line-height: 1px; padding-top: 15px; padding-right: 3px; padding-bottom: 15px; padding-left: 3px; text-align: center;">
			<p class="thwec-social-icon" style="margin: 0px; text-decoration: none; box-shadow: none; width: 40px; height: 40px;">
				<a href="https://mail.google.com/mail/?view=cm&to=ventas@bigcom.com.mx&bcc=ventas@bigcom.com.mx" class="mail">
					<img src="https://bigcom.com.mx/cdn/uploads/2022/05/RS-4.png" alt="Google Icon" width="40" height="40" style="width: 100%; height: 100%; display: block;">
				</a>
			</p>
		</td>
<td class="thwec-social-td thwec-td-yb" style="vertical-align: top; box-sizing: border-box; padding: 15px 3px 15px 3px; font-size: 0; line-height: 1px; padding-top: 15px; padding-right: 3px; padding-bottom: 15px; padding-left: 3px; text-align: center;">
			<p class="thwec-social-icon" style="margin: 0px; text-decoration: none; box-shadow: none; width: 40px; height: 40px;">
				<a href="https://www.youtube.com/channel/UCp84bOODy4dWl70Nb4gbQmw" class="youtube">
					<img src="https://bigcom.com.mx/cdn/uploads/2022/05/RS-5.png" alt="Youtube Icon" width="40" height="40" style="width: 100%; height: 100%; display: block;">
				</a>
			</p>
		</td>
<td class="thwec-social-td thwec-td-lin" style="vertical-align: top; box-sizing: border-box; padding: 15px 3px 15px 3px; font-size: 0; line-height: 1px; padding-top: 15px; padding-right: 3px; padding-bottom: 15px; padding-left: 3px; text-align: center;">
			<p class="thwec-social-icon" style="margin: 0px; text-decoration: none; box-shadow: none; width: 40px; height: 40px;">
				<a href="https://www.linkedin.com/in/bigcom-ecommerce/" class="linkedin">
					<img src="https://bigcom.com.mx/cdn/uploads/2022/05/RS-3.png" alt="Linkedin Icon" width="40" height="40" style="width: 100%; height: 100%; display: block;">
				</a>
			</p>
		</td>
<td class="thwec-social-td thwec-td-insta" style="vertical-align: top; box-sizing: border-box; padding: 15px 3px 15px 3px; font-size: 0; line-height: 1px; padding-top: 15px; padding-right: 3px; padding-bottom: 15px; padding-left: 3px; text-align: center;">
	  		<p class="thwec-social-icon" style="margin: 0px; text-decoration: none; box-shadow: none; width: 40px; height: 40px;">
	  			<a href="https://www.instagram.com/bigcomoficial1/" class="instagram">
	    			<img src="https://bigcom.com.mx/cdn/uploads/2022/05/RS-2.png" alt="Instagram Icon" width="40" height="40" style="width: 100%; height: 100%; display: block;">
	  			</a>
	  		</p>
	  	</td>
</tr>
</table>
</td>
</tr>
</table>
</td></tr></table>
</td></tr></table></div></td></tr></table>
</body>
</html>
