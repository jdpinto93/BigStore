<!DOCTYPE html>
<html lang="en-US">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Bigcom</title>
</head>
<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0">
<?php if( !isset( $order ) && isset( $gift_card->order_id ) ){
				$order = wc_get_order( $gift_card->order_id );
			} ?><?php if( isset( $order ) && is_a( $order, 'WC_Order_Refund' ) ){
				$order = wc_get_order( $order->get_parent_id() );
			} ?><table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="thwec_template_wrapper"><tr><td align="center" class="thwec-template-wrapper-column" valign="top" style="background-color: #f7f7f7; padding: 70px 0;"><div id="thwec_template_container"><table id="tp_temp_builder" width="600" cellspacing="0" cellpadding="0" class="main-builder thwec-template-block" style="max-width: 600px; width: 600px; margin: auto; box-sizing: border-box;"><tr><td class="thwec-builder-column" style="vertical-align: top; border-style: solid; border-color: #f6f7fa; background-color: #f6f6f6; background-image: none; background-position: center; background-size: 100%; background-repeat: no-repeat; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px;">
<table class="thwec-row thwec-block-one-column builder-block" id="tp_1006" cellpadding="0" cellspacing="0" style="border-spacing: 0px; width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border-style: none; border-color: transparent; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;"><tr><td class="column-padding thwec-col thwec-columns" id="tp_1007" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; vertical-align: top; width: 100%; border-style: none; border-color: transparent; background-color: transparent; background-image: none; background-position: center; background-size: 100%; background-repeat: no-repeat; text-align: center; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px;"><table class="thwec-block thwec-block-image builder-block" id="tp_1019" cellspacing="0" cellpadding="0" align="center" style="table-layout: fixed; width: 100%; height: auto; max-width: 600px; box-sizing: border-box; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-color: transparent;">
		<tr>
			<td class="thwec-block-child thwec-image-column" style="padding: 0; vertical-align: top; box-sizing: border-box; text-align: center;"><p style="padding: 5px 5px; margin: 0; display: inline-block; max-width: 100%; vertical-align: top; width: 100%; height: auto; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
			<img src="https://bigcom.com.mx/cdn/uploads/2022/05/Banner-enmaquetado-E-mail-2.png" alt="Image" width="598" height="269.094" style="width: 100%; height: auto; display: block;">
		</p></td>
</tr>
</table></td></tr></table>
<table class="thwec-row thwec-block-one-column builder-block" id="tp_1009" cellpadding="0" cellspacing="0" style="border-spacing: 0px; width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border-style: none; border-color: transparent; background-image: url('https://bigcom.com.mx/cdn/uploads/2022/05/E-mail-marketing-pedido-1-1.png'); background-color: #fefefe; background-position: center; background-size: 100%; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;"><tr><td class="column-padding thwec-col thwec-columns" id="tp_1010" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; vertical-align: top; width: 100%; border-style: none; border-color: #dddddd; background-color: transparent; background-image: none; background-position: center; background-size: 100%; background-repeat: no-repeat; text-align: left; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 15px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px;">
<table class="thwec-block thwec-block-header builder-block thwec-block-set" id="tp_1020" cellspacing="0" cellpadding="0" align="center" style="table-layout: fixed; overflow: hidden; text-align: center; box-sizing: border-box; position: relative; margin: 0 auto; max-width: 100%; width: 100%; background-color: #ff0000; background-image: none; background-repeat: no-repeat; background-position: center; background-size: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
<tr>
			<td class="header-text" style="vertical-align: top; box-sizing: border-box; padding: 30px 0px 30px 0px; font-size: 0; padding-top: 15px; padding-right: 0px; padding-bottom: 15px; padding-left: 0px;">
				<h1 style="margin: 0 auto; width: 100%; max-width: 100%; mso-line-height-rule: exactly; vertical-align: middle; border: 1px solid transparent; box-sizing: border-box; font-size: 40px; color: #ffffff; font-weight: 650; text-align: center; line-height: 100%; font-family: Arial, Helvetica, sans-serif;">Restablecer Contraeña</h1>
			</td>
		</tr>
	</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1011" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; font-size: 18px; line-height: 22px; font-weight: 600; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; text-align: left;">
		<tr style="color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; text-align: left; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 20px; padding-right: 0px; padding-bottom: 0px; padding-left: 10px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"><?php if(isset($user_login)){ ?><?php echo '<strong>' . esc_html( $user_login ) . '</strong>' ?><?php } ?> la familia BIGCOM esta encantada de atender tu solicitud, ten encuenta que este correo es para hacer cambio de tu contraseña actual y tiene un periodo de validez de 24 Horas.<br style="color: #000000; font-size: 18px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1064" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; text-align: center; font-size: 17px; line-height: 22px; font-weight: 700; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #000000; font-size: 17px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 17px; font-weight: 700; line-height: 22px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 17px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">¡Es nuestro desafío ser tu mejor opción!<br style="color: #000000; font-size: 17px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
</td></tr></table>
<table class="thwec-row thwec-block-one-column builder-block" id="tp_1047" cellpadding="0" cellspacing="0" style="width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border-spacing: 0px; padding-top: 0px; padding-right: 10px; padding-bottom: 12px; padding-left: 10px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: url('https://bigcom.com.mx/cdn/uploads/2022/05/E-mail-marketing-pedido-1-2.png'); background-color: #ffffff; background-position: center; background-size: 100%; background-repeat: no-repeat;"><tr><td class="column-padding thwec-col thwec-columns" id="tp_1048" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 100%; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; text-align: center; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; vertical-align: top;"><table class="thwec-block thwec-block-text builder-block" id="tp_1022" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; text-align: left; font-size: 17px; line-height: 22px; font-weight: 650; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; text-align: left; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 10px; padding-right: 5px; padding-bottom: 0px; padding-left: 5px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">-Contamos con mas de 30,000 productos de tus marcas Favoritas a un ¡Gran Precio!<br style="color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
<div class="wec-txt-wrap" style="color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">-Podrás Comprar hasta 18 pagos mensuales sin tener tarjeta de crédito<br style="color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
<div class="wec-txt-wrap" style="color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">-Podrás recibir tu producto el mismo día.<br style="color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
<div class="wec-txt-wrap" style="color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"><br style="color: #000000; font-size: 17px; font-weight: 650; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"></div>
			</td>
		</tr>
	</table></td></tr></table>
<table class="thwec-row thwec-block-one-column builder-block" id="tp_1071" cellpadding="0" cellspacing="0" style="width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border-spacing: 0px; padding-top: 12px; padding-right: 10px; padding-bottom: 12px; padding-left: 10px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: transparent; background-image: url('https://bigcom.com.mx/cdn/uploads/2022/05/E-mail-marketing-pedido-1-3.png'); background-color: #ffffff; background-position: center; background-size: 100%; background-repeat: no-repeat;"><tr><td class="column-padding thwec-col thwec-columns" id="tp_1072" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 100%; padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px; text-align: center; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: transparent; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; vertical-align: top;">
<table class="thwec-block thwec-block-text builder-block" id="tp_1069" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; text-align: center; font-size: 22px; line-height: 22px; font-weight: 700; font-family: 'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #000000; font-size: 22px; font-weight: 700; line-height: 22px; font-family: 'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 22px; font-weight: 700; line-height: 22px; text-align: center; font-family: 'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 22px; font-weight: 700; line-height: 22px; font-family: 'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif;">¡Aqui te dejamos los detalles de tu cuenta!<br style="color: #000000; font-size: 22px; font-weight: 700; line-height: 22px; font-family: 'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif;">
</div>
			</td>
		</tr>
	</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1068" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #ff0000; text-align: center; font-size: 22px; line-height: 22px; font-weight: 700; font-family: Arial, Helvetica, sans-serif; width: 80%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #ff0000; font-size: 22px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #ff0000; font-size: 22px; font-weight: 700; line-height: 22px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 2px; border-right-width: 2px; border-bottom-width: 2px; border-left-width: 2px; border-color: #000000; border-style: solid; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #ff0000; font-size: 22px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">Usuario:  <?php if(isset($user_login)){ ?><?php echo '<strong>' . esc_html( $user_login ) . '</strong>' ?><?php } ?><br style="color: #ff0000; font-size: 22px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
<div class="wec-txt-wrap" style="color: #ff0000; font-size: 22px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"><br style="color: #ff0000; font-size: 22px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"></div>
<div class="wec-txt-wrap" style="color: #ff0000; font-size: 22px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">Contraseña: <?php if(isset($reset_key) && isset($user_id)): ?><a class="link thwec-link" href="<?php echo esc_url( add_query_arg( array( 'key' => $reset_key, 'id' => $user_id ), wc_get_endpoint_url( 'lost-password', '', wc_get_page_permalink( 'myaccount' ) ) ) ); ?>">
			<?php _e( 'Click here to reset your password', 'woocommerce' ); ?></a><?php endif; ?><br style="color: #ff0000; font-size: 22px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1075" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #ff0000; text-align: center; font-size: 18px; line-height: 22px; font-weight: bold; font-family: 'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #ff0000; font-size: 18px; font-weight: bold; line-height: 22px; font-family: 'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #ff0000; font-size: 18px; font-weight: bold; line-height: 22px; text-align: center; font-family: 'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #ff0000; font-size: 18px; font-weight: bold; line-height: 22px; font-family: 'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif;">Si no realizó esta solicitud, simplemente ignore este correo electrónico.<br style="color: #ff0000; font-size: 18px; font-weight: bold; line-height: 22px; font-family: 'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif;">
</div>
			</td>
		</tr>
	</table>
</td></tr></table>
<table class="thwec-row thwec-block-four-column builder-block" id="tp_1051" cellpadding="0" cellspacing="0" style="border-spacing: 0px; width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; padding-top: 12px; padding-right: 10px; padding-bottom: 12px; padding-left: 10px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: url('http://localhost/bigcom/wp-content/uploads/2022/05/E-mail-marketing-pedido-1-3.png'); background-color: #ffffff; background-position: center; background-size: 100%; background-repeat: no-repeat;"><tr>
<td class="column-padding thwec-col thwec-columns" id="tp_1052" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 25%; padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; text-align: center; vertical-align: top;">
<table class="thwec-block thwec-block-image builder-block" id="tp_1056" cellspacing="0" cellpadding="0" align="center" style="table-layout: fixed; width: 100%; height: auto; max-width: 600px; box-sizing: border-box; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-color: transparent;">
		<tr>
			<td class="thwec-block-child thwec-image-column" style="padding: 0; vertical-align: top; box-sizing: border-box; text-align: center;"><p style="padding: 5px 5px; margin: 0; display: inline-block; max-width: 100%; vertical-align: top; width: 100%; height: 85px; padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
			<img src="https://bigcom.com.mx/cdn/uploads/2022/05/Iconos-PUV-5-150px-1.png" alt="Image" width="124.5" height="85" style="width: 100%; height: auto; display: block;">
		</p></td>
</tr>
</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1060" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; text-align: center; font-size: 9px; line-height: 15px; font-weight: 800; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">Compras 100% Seguras<br style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
</td>
<td class="column-padding thwec-col thwec-columns" id="tp_1053" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 25%; padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; text-align: center; vertical-align: top;">
<table class="thwec-block thwec-block-image builder-block" id="tp_1057" cellspacing="0" cellpadding="0" align="center" style="table-layout: fixed; width: 100%; height: auto; max-width: 600px; box-sizing: border-box; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-color: transparent;">
		<tr>
			<td class="thwec-block-child thwec-image-column" style="padding: 0; vertical-align: top; box-sizing: border-box; text-align: center;"><p style="padding: 5px 5px; margin: 0; display: inline-block; max-width: 100%; vertical-align: top; width: 100%; height: 85px; padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
			<img src="https://bigcom.com.mx/cdn/uploads/2022/05/Iconos-PUV-2-150px-2.png" alt="Image" width="124.5" height="85" style="width: 100%; height: auto; display: block;">
		</p></td>
</tr>
</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1061" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; text-align: center; font-size: 9px; line-height: 15px; font-weight: 800; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">Entregas el mismo Día<br style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
</td>
<td class="column-padding thwec-col thwec-columns" id="tp_1054" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 25%; padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; text-align: center; vertical-align: top;">
<table class="thwec-block thwec-block-image builder-block" id="tp_1058" cellspacing="0" cellpadding="0" align="center" style="table-layout: fixed; width: 100%; height: auto; max-width: 600px; box-sizing: border-box; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-color: transparent;">
		<tr>
			<td class="thwec-block-child thwec-image-column" style="padding: 0; vertical-align: top; box-sizing: border-box; text-align: center;"><p style="padding: 5px 5px; margin: 0; display: inline-block; max-width: 100%; vertical-align: top; width: 100%; height: 85px; padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
			<img src="https://bigcom.com.mx/cdn/uploads/2022/05/Iconos-PUV-1-150px-1.png" alt="Image" width="124.5" height="85" style="width: 100%; height: auto; display: block;">
		</p></td>
</tr>
</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1062" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; text-align: center; font-size: 9px; line-height: 15px; font-weight: 800; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">Meses sin Tarjetas de Credito<br style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
</td>
<td class="column-padding thwec-col thwec-columns" id="tp_1055" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 25%; padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; text-align: center; vertical-align: top;">
<table class="thwec-block thwec-block-image builder-block" id="tp_1059" cellspacing="0" cellpadding="0" align="center" style="table-layout: fixed; width: 100%; height: auto; max-width: 600px; box-sizing: border-box; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-color: transparent;">
		<tr>
			<td class="thwec-block-child thwec-image-column" style="padding: 0; vertical-align: top; box-sizing: border-box; text-align: center;"><p style="padding: 5px 5px; margin: 0; display: inline-block; max-width: 100%; vertical-align: top; width: 100%; height: 85px; padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
			<img src="https://bigcom.com.mx/cdn/uploads/2022/05/Iconos-PUV-3-150px-1.png" alt="Image" width="124.5" height="85" style="width: 100%; height: auto; display: block;">
		</p></td>
</tr>
</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1063" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #000000; text-align: center; font-size: 9px; line-height: 15px; font-weight: 800; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">Atencion en linea<br style="color: #000000; font-size: 9px; font-weight: 800; line-height: 15px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
</td>
</tr></table>
<table class="thwec-row thwec-block-one-column builder-block" id="tp_1035" cellpadding="0" cellspacing="0" style="width: 100%; table-layout: fixed; max-width: 100%; margin: 0 auto; border-spacing: 0px; padding-top: 12px; padding-right: 10px; padding-bottom: 12px; padding-left: 10px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: #444444; background-position: center; background-size: 100%; background-repeat: no-repeat;"><tr><td class="column-padding thwec-col thwec-columns" id="tp_1036" style="box-sizing: border-box; word-break: break-word; padding: 10px 10px; width: 100%; padding-top: 10px; padding-right: 10px; padding-bottom: 10px; padding-left: 10px; text-align: center; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-style: none; border-color: #dddddd; background-image: none; background-color: transparent; background-position: center; background-size: 100%; background-repeat: no-repeat; vertical-align: top;">
<table class="thwec-block thwec-block-image builder-block" id="tp_1050" cellspacing="0" cellpadding="0" align="center" style="table-layout: fixed; width: 100%; height: auto; max-width: 600px; box-sizing: border-box; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-color: transparent;">
		<tr>
			<td class="thwec-block-child thwec-image-column" style="padding: 0; vertical-align: top; box-sizing: border-box; text-align: center;"><p style="padding: 5px 5px; margin: 0; display: inline-block; max-width: 100%; vertical-align: top; width: 25%; height: 100px; padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
			<img src="https://bigcom.com.mx/cdn/uploads/2022/05/Rojo.png" alt="Image" width="139.5" height="100" style="width: 100%; height: auto; display: block;">
		</p></td>
</tr>
</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1037" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #ffffff; text-align: center; font-size: 14px; line-height: 22px; font-weight: 700; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #ffffff; font-size: 14px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #ffffff; font-size: 14px; font-weight: 700; line-height: 22px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">¿Tienes alguna pregunta? Escribenos a contacto@bigcom.com.mx o puedes llamarnos al (222) 1696636<br style="color: #ffffff; font-size: 14px; font-weight: 700; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1041" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #ffffff; text-align: left; font-size: 14px; line-height: 22px; font-weight: 500; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; text-align: left; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">-- El precio, especificaciones de producto, disponibilidad y términos de las promociones pueden cambiar sin previo aviso.<br style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"><br style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"></div>
<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">-- Los precios y artículos en este correo están sujetos a disponibilidad.<br style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"><br style="color: #ffffff; font-size: 14px; font-weight: 500; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"></div>
			</td>
		</tr>
	</table>
<table class="thwec-block thwec-block-text builder-block" id="tp_1040" cellspacing="0" cellpadding="0" style="table-layout: fixed; margin: 0 auto; box-sizing: border-box; color: #ffffff; text-align: center; font-size: 14px; line-height: 22px; font-weight: 600; font-family: Arial, Helvetica, sans-serif; width: 100%; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto;">
		<tr style="color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
			<td class="thwec-block-child thwec-block-text-holder" style="vertical-align: top; box-sizing: border-box; padding: 15px 15px; color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; text-align: center; font-family: Arial, Helvetica, sans-serif; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-color: transparent; border-style: none; padding-top: 15px; padding-right: 15px; padding-bottom: 15px; padding-left: 15px;">
			<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">Bigcom © 2021. All Rights Reserved.<br style="color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"><br style="color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;"></div>
<div class="wec-txt-wrap" style="color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">Av. Pinos, Sta Cruz Buenavista, 72170 Puebla, Pue.<br style="color: #ffffff; font-size: 14px; font-weight: 600; line-height: 22px; font-family: Arial, Helvetica, sans-serif;">
</div>
			</td>
		</tr>
	</table>
<table class="thwec-block thwec-block-social builder-block" id="tp_1039" cellspacing="0" cellpadding="0" style="table-layout: fixed; width: 100%; box-sizing: border-box; margin: 0 auto; text-align: center; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; background-color: transparent; background-image: none; background-size: 100%; background-position: center; background-repeat: no-repeat; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: none; border-color: transparent;">
		<tr>
			<td class="thwec-block-child thwec-social-outer-td" align="center" style="padding: 0; vertical-align: top; box-sizing: border-box; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px;">
				<table class="thwec-social-inner-tb" cellspacing="0" cellpadding="0">
					<tr>
<td class="thwec-social-td thwec-td-fb" style="vertical-align: top; box-sizing: border-box; padding: 15px 3px 15px 3px; font-size: 0; line-height: 1px; padding-top: 15px; padding-right: 3px; padding-bottom: 15px; padding-left: 3px; text-align: center;">
			<p class="thwec-social-icon" style="margin: 0px; text-decoration: none; box-shadow: none; width: 40px; height: 40px;">
				<a href="https://www.facebook.com/BigcomOficial" class="facebook">
					<img src="https://bigcom.com.mx/cdn/uploads/2022/05/RS-1.png" alt="Facebook Icon" width="40" height="40" style="width: 100%; height: 100%; display: block;">
				</a>
			</p>
		</td>
<td class="thwec-social-td thwec-td-mail" style="vertical-align: top; box-sizing: border-box; padding: 15px 3px 15px 3px; font-size: 0; line-height: 1px; padding-top: 15px; padding-right: 3px; padding-bottom: 15px; padding-left: 3px; text-align: center;">
			<p class="thwec-social-icon" style="margin: 0px; text-decoration: none; box-shadow: none; width: 40px; height: 40px;">
				<a href="https://mail.google.com/mail/?view=cm&to=ventas@bigcom.com.mx&bcc=ventas@bigcom.com.mx" class="mail">
					<img src="https://bigcom.com.mx/cdn/uploads/2022/05/RS-4.png" alt="Google Icon" width="40" height="40" style="width: 100%; height: 100%; display: block;">
				</a>
			</p>
		</td>
<td class="thwec-social-td thwec-td-yb" style="vertical-align: top; box-sizing: border-box; padding: 15px 3px 15px 3px; font-size: 0; line-height: 1px; padding-top: 15px; padding-right: 3px; padding-bottom: 15px; padding-left: 3px; text-align: center;">
			<p class="thwec-social-icon" style="margin: 0px; text-decoration: none; box-shadow: none; width: 40px; height: 40px;">
				<a href="https://www.youtube.com/channel/UCp84bOODy4dWl70Nb4gbQmw" class="youtube">
					<img src="https://bigcom.com.mx/cdn/uploads/2022/05/RS-5.png" alt="Youtube Icon" width="40" height="40" style="width: 100%; height: 100%; display: block;">
				</a>
			</p>
		</td>
<td class="thwec-social-td thwec-td-lin" style="vertical-align: top; box-sizing: border-box; padding: 15px 3px 15px 3px; font-size: 0; line-height: 1px; padding-top: 15px; padding-right: 3px; padding-bottom: 15px; padding-left: 3px; text-align: center;">
			<p class="thwec-social-icon" style="margin: 0px; text-decoration: none; box-shadow: none; width: 40px; height: 40px;">
				<a href="https://www.linkedin.com/in/bigcom-ecommerce/" class="linkedin">
					<img src="https://bigcom.com.mx/cdn/uploads/2022/05/RS-3.png" alt="Linkedin Icon" width="40" height="40" style="width: 100%; height: 100%; display: block;">
				</a>
			</p>
		</td>
<td class="thwec-social-td thwec-td-insta" style="vertical-align: top; box-sizing: border-box; padding: 15px 3px 15px 3px; font-size: 0; line-height: 1px; padding-top: 15px; padding-right: 3px; padding-bottom: 15px; padding-left: 3px; text-align: center;">
	  		<p class="thwec-social-icon" style="margin: 0px; text-decoration: none; box-shadow: none; width: 40px; height: 40px;">
	  			<a href="https://www.instagram.com/bigcomoficial1/" class="instagram">
	    			<img src="https://bigcom.com.mx/cdn/uploads/2022/05/RS-2.png" alt="Instagram Icon" width="40" height="40" style="width: 100%; height: 100%; display: block;">
	  			</a>
	  		</p>
	  	</td>
</tr>
</table>
</td>
</tr>
</table>
</td></tr></table>
</td></tr></table></div></td></tr></table>
</body>
</html>
