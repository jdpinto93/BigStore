<?php

echo '<h1> Bienvenidos al panel de administracion </h1>';
?>
<br>

<div>
  <div class="contenTarjetas">

    <div class="tarjetasAdmin">
    <img src="#" class="img-thumbnail border-0" alt="...">
  <div class="infotarjeta">
    <h3 class="titleAdmin">Configuracion de WhatsApp</h3><br>
    <a href="admin.php?page=WhatsApp" class="botonTarjetas">Configurar WhatsApp</a>
  </div>
    </div>

    <div class="tarjetasAdmin">
    <img src="#" class="img-thumbnail border-0" alt="...">
  <div class="infotarjeta">
    <h3  class="titleAdmin">Configuración de Merchant ID</h3><br>
    <a href="options-general.php?page=ecr_gcr" class="botonTarjetas">Configurar Merchant ID</a>
  </div>
    </div>

    <div class="tarjetasAdmin">
    <img src="#" class="img-thumbnail border-0" alt="...">
  <div class="infotarjeta">
    <h3  class="titleAdmin">Configuración de Carrito</h3><br>
    <a href="admin.php?page=jp_cp" class="botonTarjetas">Configurar Carrito</a>
  </div>
    </div>
  </div>
</div>

<br>

<div>
  <div class="contenTarjetas">

    <div class="tarjetasAdmin">
    <img src="#" class="img-thumbnail border-0" alt="...">
  <div class="infotarjeta">
    <h3 class="titleAdmin">Configuracion de Emails</h3><br>
    <a href="edit.php?post_type=viwec_template" class="botonTarjetas">Configurar Emails</a>
  </div>
    </div>

    <div class="tarjetasAdmin">
    <img src="#" class="img-thumbnail border-0" alt="...">
  <div class="infotarjeta">
    <h3  class="titleAdmin">Configuración de Pedidos</h3><br>
    <a href="edit.php?post_type=wc_order_status" class="botonTarjetas">Configurar Pedidos</a>
  </div>
    </div>

    <div class="tarjetasAdmin">
    <img src="#" class="img-thumbnail border-0" alt="...">
  <div class="infotarjeta">
    <h3  class="titleAdmin">Personalizar txt Botones</h3><br>
    <a href="admin.php?page=wc-settings&tab=customizer" class="botonTarjetas">Personalizar Botones</a>
  </div>
    </div>
  </div>
</div>