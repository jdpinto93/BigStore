<?php
if(!defined('WPINC')){	die; }

if(!class_exists('THWCFE_Deactivator')):

class THWCFE_Deactivator {

	/**
	 *
	 * @since    2.3.0
	 */
	public static function deactivate() {

	}

}

endif;